const celciusInput = document.querySelector('#celcius > input');
const fahrenhitInput = document.querySelector('#fahrenhit > input');
const kelvinInput = document.querySelector('#kelvin > input');


function roundNum(num) {
    return Math.round(num*100)/100;
}

function celciusToFerheinetAndKelvin() {
    var cTemp = parseFloat(celciusInput.value);
    var fTemp = (cTemp *(9/5)) + 32;
    var kTemp = (cTemp + 273.15);

    fahrenhitInput.value = roundNum(fTemp);
    kelvinInput.value = roundNum(kTemp);
}

function ferhenitToCelciusAndKelvin() {
    var fTemp = parseFloat(fahrenhitInput.value);
    var cTemp = (fTemp - 32) * (5/9);
    var kTemp = (fTemp + 459.67) * 5/9;

    celciusInput.value = roundNum(cTemp);
    kelvinInput.value = roundNum(kTemp);
}

function kelvinToCelciusAndFerhenit() {
    var kTemp = parseFloat(kelvinInput.value);
    var cTemp = (kTemp - 273.15);
    var fTemp = 9/5 * (kTemp - 273) + 32;

    celciusInput.value = roundNum(cTemp);
    fahrenhitInput.value = roundNum(cTemp);
}



function main() {
    celciusInput.addEventListener('input', celciusToFerheinetAndKelvin);
    fahrenhitInput.addEventListener('input', ferhenitToCelciusAndKelvin)
    kelvinInput.addEventListener('input',kelvinToCelciusAndFerhenit)
}

main();